"""
回文检查模块
提供检查字符串是否为回文的函数
"""

# 回文判断函数
def is_palindrome(text):
    """
    检查字符串是否为回文
    
    参数:
        text (str): 要检查的字符串  
    返回:
        bool: 如果是回文返回True，否则返回False  
    异常:
        TypeError: 如果输入不是字符串类型
    """
    if not isinstance(text, str):
        raise TypeError("输入必须是字符串")
    
    # 移除空格并转换为小写
    cleaned_text = ''.join(text.lower().split())
    # 检查空字符串或单字符情况
    if len(cleaned_text) <= 1:
        return True

    return cleaned_text == cleaned_text[::-1]

# 回文判断函数（忽略标点符号和空格）
def is_palindrome_with_punctuation(text):
    """
    检查字符串是否为回文，忽略标点符号和空格
    
    参数:
        text (str): 要检查的字符串
        
    返回:
        bool: 如果是回文返回True，否则返回False
    """
    if not isinstance(text, str):
        raise TypeError("输入必须是字符串")
    
    # 移除标点符号和空格，转换为小写
    import string
    cleaned_text = ''.join(
        char.lower() for char in text 
        if char.isalnum()  # 只保留字母和数字
    )
    
    return cleaned_text == cleaned_text[::-1]