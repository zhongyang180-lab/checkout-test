
import pytest
import sys
import os

# 添加src目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.palindrome import is_palindrome, is_palindrome_with_punctuation
# 测试用例设计采用分层策略，从简单到复杂覆盖所有功能路径
def test_basic_palindrome():
    """测试基本回文功能"""
    assert is_palindrome("radar") == True
    assert is_palindrome("hello") == False
# 测试包含空格和大小写的回文
def test_palindrome_with_spaces_and_case():
    """测试包含空格和大小写的回文"""
    assert is_palindrome("A man a plan a canal panama") == True
    assert is_palindrome("Racecar") == True
# 测试边界情况
def test_edge_cases():
    """测试边界情况"""
    assert is_palindrome("") == True      # 空字符串
    assert is_palindrome("a") == True     # 单字符
    assert is_palindrome("12321") == True # 数字回文
# 测试包含标点符号的回文
def test_palindrome_with_punctuation():
    """测试包含标点符号的回文"""
    assert is_palindrome_with_punctuation("A man, a plan, a canal: Panama") == True
    assert is_palindrome_with_punctuation("Was it a car or a cat I saw?") == True
# 测试无效输入类型
def test_invalid_input():
    """测试无效输入类型"""
    with pytest.raises(TypeError):
        is_palindrome(123)
    
    with pytest.raises(TypeError):
        is_palindrome(None)
# 综合参数化测试
def test_comprehensive_parametrized():
    """综合参数化测试"""
    test_cases = [
        ("radar", True),           # 简单回文
        ("hello", False),          # 非回文  
        ("A Santa at NASA", True), # 包含空格
        ("", True),                # 空字符串
        ("a", True),               # 单字符
        ("12321", True),           # 数字回文
        ("Racecar", True),         # 大小写混合
    ]
    
    for text, expected in test_cases:
        assert is_palindrome(text) == expected