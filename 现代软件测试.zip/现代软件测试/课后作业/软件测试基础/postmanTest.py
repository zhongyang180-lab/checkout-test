from flask import Flask, jsonify, request

app = Flask(__name__)

# 模拟学生数据库
students = [
    {"id": 1, "name": "张三", "age": 20, "class": "计算机1班", "score": 85},
    {"id": 2, "name": "李四", "age": 21, "class": "计算机2班", "score": 92},
    {"id": 3, "name": "王五", "age": 19, "class": "计算机1班", "score": 78},
    {"id": 4, "name": "赵六", "age": 22, "class": "计算机3班", "score": 88}
]

# 1. 首页
@app.route('/')
def home():
    return jsonify({
        "message": "学生信息管理系统（参数测试版）",
        "status": "success",
        "endpoints": {
            "查询所有学生": "GET /api/students",
            "按ID查询学生": "GET /api/students?id=1",
            "按班级查询": "GET /api/students?class=计算机1班", 
            "按分数范围查询": "GET /api/students?min_score=80&max_score=90",
            "添加学生": "POST /api/students",
            "搜索学生": "GET /api/students/search?name=张"
        }
    })

# 2. 获取学生列表（支持多种查询参数）
@app.route('/api/students', methods=['GET'])
def get_students():
    # 获取查询参数
    student_id = request.args.get('id', type=int)
    class_name = request.args.get('class')
    min_score = request.args.get('min_score', type=int)
    max_score = request.args.get('max_score', type=int)
    
    result = students.copy()
    
    # 根据ID过滤
    if student_id:
        result = [s for s in result if s['id'] == student_id]
    
    # 根据班级过滤
    if class_name:
        result = [s for s in result if s['class'] == class_name]
    
    # 根据分数范围过滤
    if min_score is not None:
        result = [s for s in result if s['score'] >= min_score]
    
    if max_score is not None:
        result = [s for s in result if s['score'] <= max_score]
    
    return jsonify({
        "status": "success",
        "count": len(result),
        "filters": {
            "id": student_id,
            "class": class_name,
            "min_score": min_score,
            "max_score": max_score
        },
        "students": result
    })

# 3. 搜索学生（按姓名模糊搜索）
@app.route('/api/students/search', methods=['GET'])
def search_students():
    name = request.args.get('name', '')
    
    if not name:
        return jsonify({
            "status": "error",
            "message": "请提供姓名参数"
        }), 400
    
    # 模糊搜索
    result = [s for s in students if name in s['name']]
    
    return jsonify({
        "status": "success",
        "search_keyword": name,
        "count": len(result),
        "students": result
    })

# 4. 添加新学生（通过请求体参数）
@app.route('/api/students', methods=['POST'])
def add_student():
    # 从请求体中获取JSON参数
    data = request.get_json()
    
    # 检查必要参数
    if not data or 'name' not in data:
        return jsonify({
            "status": "error",
            "message": "必须提供学生姓名"
        }), 400
    
    # 创建新学生
    new_student = {
        "id": len(students) + 1,
        "name": data.get('name'),
        "age": data.get('age', 18),
        "class": data.get('class', '未分班'),
        "score": data.get('score', 0)
    }
    
    students.append(new_student)
    
    return jsonify({
        "status": "success",
        "message": "学生添加成功",
        "student": new_student
    }), 201

# 5. 更新学生信息（混合使用URL参数和请求体参数）
@app.route('/api/students/<int:student_id>', methods=['PUT'])
def update_student(student_id):
    # 查找学生
    student = next((s for s in students if s['id'] == student_id), None)
    
    if not student:
        return jsonify({
            "status": "error",
            "message": f"学生ID {student_id} 不存在"
        }), 404
    
    # 从请求体获取更新数据
    data = request.get_json()
    
    # 更新学生信息
    if 'name' in data:
        student['name'] = data['name']
    if 'age' in data:
        student['age'] = data['age']
    if 'class' in data:
        student['class'] = data['class']
    if 'score' in data:
        student['score'] = data['score']
    
    return jsonify({
        "status": "success",
        "message": "学生信息更新成功",
        "student": student
    })

if __name__ == '__main__':
    print("🎯 参数测试服务器启动！")
    print("📍 访问地址: http://localhost:5000")
    print("📖 查看所有接口说明: http://localhost:5000/")
    app.run(debug=True, port=5000)