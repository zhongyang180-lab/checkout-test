import pytest
from defective_functions import divide, find_max, get_item

def test_divide_normal_operation():
    """测试用例1: divide函数正常除法运算"""
    result = divide(10, 2)
    assert result == 5.0

def test_divide_by_zero():
    """测试用例2: divide函数除数为零测试"""
    # 测试数据: a=10, b=0
    # 预期结果: 抛出ZeroDivisionError异常
    # 实际结果: ZeroDivisionError: division by zero
    # 测试状态: ✗ 失败（触发了缺陷1）
    with pytest.raises(ZeroDivisionError):
        divide(10, 0)

def test_find_max_positive_numbers():
    """测试用例3: find_max函数正常正数列表"""
    # 测试数据: lst = [3, 7, 2, 9, 1]
    # 预期结果: 9
    # 实际结果: 9
    # 测试状态: ✓ 通过
    test_list = [3, 7, 2, 9, 1]
    result = find_max(test_list)
    assert result == 9

def test_find_max_all_negative_numbers():
    """测试用例4: find_max函数全负数列表"""
    # 测试数据: lst = [-5, -2, -8, -1]
    # 预期结果: -1
    # 实际结果: 0
    # 测试状态: ✗ 失败（触发了缺陷2）
    test_list = [-5, -2, -8, -1]
    result = find_max(test_list)
    assert result == -1  # 这个断言会失败，因为缺陷2

def test_get_item_valid_index():
    """测试用例5: get_item函数有效索引访问"""
    # 测试数据: lst = [10, 20, 30], idx=1
    # 预期结果: 20
    # 实际结果: 20
    # 测试状态: ✓ 通过
    test_list = [10, 20, 30]
    result = get_item(test_list, 1)
    assert result == 20

def test_get_item_index_out_of_range():
    """测试用例6: get_item函数索引越界测试"""
    # 测试数据: lst = [10, 20, 30], idx=5
    # 预期结果: 抛出IndexError异常
    # 实际结果: IndexError: list index out of range
    # 测试状态: ✗ 失败（触发了缺陷3）
    test_list = [10, 20, 30]
    with pytest.raises(IndexError):
        get_item(test_list, 5)

def test_find_max_empty_list():
    """测试用例7: find_max函数空列表特殊情况"""
    # 测试数据: lst = []
    # 预期结果: None或抛出ValueError
    # 实际结果: 0
    # 测试状态: ✗ 失败（发现额外缺陷）
    test_list = []
    result = find_max(test_list)
    # 期望返回None或抛出异常，但实际返回0
    assert result is None  # 这个断言会失败，因为额外缺陷