import pytest
from book_management import BookManagementSystem


class TestBookManagement:
    """图书管理系统测试类"""
    # 每个测试方法前执行，初始化系统
    def setup_method(self):
        """每个测试方法前执行，初始化系统"""
        self.system = BookManagementSystem()
        # 设置测试数据
        self.system.add_user("user1")
        self.system.add_user("user2")
        self.system.add_book("book1")
        self.system.add_book("book2")
        self.system.add_book("book3")
        self.system.set_book_stock("book1", 5)  # 正常库存
        self.system.set_book_stock("book2", 1)  # 少量库存
        self.system.set_book_stock("book3", 0)  # 零库存
    # 测试正常借书成功的情况
    def test_borrow_book_success(self):
        """测试正常借书成功的情况"""
        # 执行借书操作
        result = self.system.borrow_book("user1", "book1")
        
        # 验证结果
        assert result is True
        assert self.system.get_book_info("book1")["stock"] == 4  # 库存减少
        assert "book1" in self.system.get_user_info("user1")["borrowed_books"]  # 用户借书记录
    # 测试用户不存在的情况
    def test_borrow_book_user_not_exists(self):
        """测试用户不存在的情况"""
        # 验证抛出异常
        with pytest.raises(ValueError, match="用户 nonexistent_user 不存在"):
            self.system.borrow_book("nonexistent_user", "book1")
    # 测试图书不存在的情况
    def test_borrow_book_not_exists(self):
        """测试图书不存在的情况"""
        # 验证抛出异常
        with pytest.raises(ValueError, match="图书 nonexistent_book 不存在"):
            self.system.borrow_book("user1", "nonexistent_book")
    # 测试库存为0的情况
    def test_borrow_book_out_of_stock(self):
        """测试库存为0的情况"""
        # 验证抛出异常
        with pytest.raises(ValueError, match="图书 book3 库存不足，当前库存: 0"):
            self.system.borrow_book("user1", "book3")
    # 测试借书后库存正确减少
    def test_borrow_book_stock_reduction(self):
        """测试借书后库存正确减少"""
        # 多次借同一本书
        self.system.borrow_book("user1", "book1")
        self.system.borrow_book("user2", "book1")
        
        # 验证库存正确减少
        assert self.system.get_book_info("book1")["stock"] == 3
    # 测试有限库存的情况
    def test_borrow_book_limited_stock(self):
        """测试有限库存的情况"""
        # 第一次借书应该成功
        result1 = self.system.borrow_book("user1", "book2")
        assert result1 is True
        assert self.system.get_book_info("book2")["stock"] == 0
        
        # 第二次借同一本书应该失败
        with pytest.raises(ValueError, match="图书 book2 库存不足，当前库存: 0"):
            self.system.borrow_book("user2", "book2")
    # 测试多个用户借书的情况
    def test_borrow_book_multiple_users(self):
        """测试多个用户借书的情况"""
        # 用户1借书
        self.system.borrow_book("user1", "book1")
        # 用户2借同一本书
        self.system.borrow_book("user2", "book1")
        
        # 验证两个用户都有借书记录
        user1_books = self.system.get_user_info("user1")["borrowed_books"]
        user2_books = self.system.get_user_info("user2")["borrowed_books"]
        
        assert "book1" in user1_books
        assert "book1" in user2_books
        assert self.system.get_book_info("book1")["stock"] == 3

if __name__ == "__main__":
    # 运行测试
    pytest.main([__file__, "-v"])