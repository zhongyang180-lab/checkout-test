class BookManagementSystem:
    def __init__(self):
        self.users = {}  # 用户字典 {user_id: user_info}
        self.books = {}  # 图书字典 {book_id: book_info}
    #添加用户
    def add_user(self, user_id, user_info=None):
        """添加用户"""
        if user_id in self.users:
            raise ValueError(f"用户 {user_id} 已存在")
        self.users[user_id] = user_info or {"name": f"User_{user_id}", "borrowed_books": []}
    #添加书籍
    def add_book(self, book_id, book_info=None):
        """添加图书"""
        if book_id in self.books:
            raise ValueError(f"图书 {book_id} 已存在")
        self.books[book_id] = book_info or {
            "title": f"Book_{book_id}", 
            "author": "Unknown", 
            "stock": 0
        }
    #设置书籍库存
    def set_book_stock(self, book_id, stock):
        """设置图书库存"""
        if book_id not in self.books:
            raise ValueError(f"图书 {book_id} 不存在")
        self.books[book_id]["stock"] = stock
    #借书功能
    def borrow_book(self, user, book):
        """
        借书功能
        Args:
            user: 用户ID
            book: 图书ID   
        Returns:
            bool: 借书是否成功   
        Raises:
            ValueError: 当用户不存在、图书不存在或库存不足时抛出异常
        """
        # 1. 检查用户是否存在
        if user not in self.users:
            raise ValueError(f"用户 {user} 不存在")
        # 2. 检查图书是否存在
        if book not in self.books:
            raise ValueError(f"图书 {book} 不存在") 
        # 3. 检查图书是否可借（库存 > 0）
        if self.books[book]["stock"] <= 0:
            raise ValueError(f"图书 {book} 库存不足，当前库存: {self.books[book]['stock']}")
        # 执行借书操作
        self.books[book]["stock"] -= 1
        self.users[user]["borrowed_books"].append(book)
        
        return True
    #获取用户信息
    def get_user_info(self, user_id):
        """获取用户信息"""
        return self.users.get(user_id)
    #获取书籍信息
    def get_book_info(self, book_id):
        """获取图书信息"""
        return self.books.get(book_id)