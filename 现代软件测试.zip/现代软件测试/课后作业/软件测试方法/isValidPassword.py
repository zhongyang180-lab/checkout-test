import re

def isValidPassword(s: str) -> bool:
 
    # 1. 处理非字符串输入（如 None、数字、列表等），直接返回 False
    if not isinstance(s, str):
        return False
    
    # 2. 验证长度：必须在 6-12 位之间（含 6 和 12）
    if not (6 <= len(s) <= 12):
        return False
    
    # 3. 验证内容：必须同时包含字母（大小写均可）和数字
    has_letter = re.search(r'[a-zA-Z]', s)  # 匹配任意字母
    has_digit = re.search(r'\d', s)         # 匹配任意数字
    
    # 只有同时存在字母和数字，才满足内容约束
    return has_letter is not None and has_digit is not None


# ------------------------------ 测试用例验证 ------------------------------
if __name__ == "__main__":
    # 测试用例：覆盖有效、无效等价类及边界场景
    test_cases = [
        # 有效等价类（预期 True）
        ("Abc123", True),        # 6位，纯字母+数字
        ("a1@3b5c7", True),      # 8位，含特殊符号
        (" 123XyZ! ", True),     # 10位，含空格+特殊符号
        ("9876543210ab", True),  # 12位，最大边界
        
        # 无效等价类 - 长度不足（预期 False）
        ("", False),             # 0位空字符串
        ("a123", False),         # 4位，含字母+数字
        ("!@#$5", False),        # 5位，含数字+特殊符号
        
        # 无效等价类 - 长度超界（预期 False）
        ("a123456789012", False),# 13位，含字母+数字
        ("HelloWorld1234", False),#14位，含字母+数字
        
        # 无效等价类 - 仅含字母（预期 False）
        ("AbcDefGh", False),     # 8位，纯字母
        ("XYZ!@#$", False),      # 6位，字母+特殊符号（无数字）
        
        # 无效等价类 - 仅含数字（预期 False）
        ("123456", False),       # 6位，纯数字
        ("98765432!@", False),   # 10位，数字+特殊符号（无字母）
        
        # 无效等价类 - 无字母无数字（预期 False）
        ("!@#$%^&*", False),     # 8位，纯特殊符号
        ("   （）【】", False),   # 6位，空格+中文符号
        
        # 边界值场景（预期对应结果）
        ("a1234", False),        # 5位（最小边界-1）
        ("a12345", True),        # 6位（最小边界）
        ("9876543210abc", False),#13位（最大边界+1）
        
        # 非字符串输入（预期 False）
        (None, False),
        (123456, False),
        ([1,2,3], False)
    ]

    # 执行测试并输出结果
    for input_str, expected in test_cases:
        result = isValidPassword(input_str)
        status = "PASS" if result == expected else "FAIL"
        print(f"输入: {repr(input_str)} | 预期: {expected} | 实际: {result} | 状态: {status}")