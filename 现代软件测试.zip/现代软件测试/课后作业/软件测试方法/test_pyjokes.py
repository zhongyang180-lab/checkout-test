import pytest
import pyjokes
from pyjokes.exc import LanguageNotFoundError, CategoryNotFoundError

def test_get_joke_default_params():
    """用例TC-001：默认参数调用get_joke()"""
    joke = pyjokes.get_joke()
    assert isinstance(joke, str), "返回结果必须是字符串"
    assert len(joke.strip()) > 5, "笑话长度过短，不符合正常内容"

def test_get_joke_invalid_language():
    """用例TC-002：传入不支持的语言调用get_joke()"""
    with pytest.raises(LanguageNotFoundError, match="No such language") as excinfo:
        pyjokes.get_joke(language='zh')
    assert "zh" in str(excinfo.value), "异常信息应明确指出无效语言"

def test_get_jokes_valid_category():
    """用例TC-003：有效语言+类别调用get_jokes()"""
    jokes = pyjokes.get_jokes(language='en', category='chuck')
    assert isinstance(jokes, list), "返回结果必须是列表"
    assert len(jokes) > 0, "chuck类别应包含至少1个笑话"
    for joke in jokes:
        assert isinstance(joke, str), "列表元素必须是字符串"
        assert len(joke.strip()) > 10, "笑话内容应符合正常长度"

def test_get_joke_invalid_category():
    """用例TC-004：传入不支持的类别调用get_joke()"""
    with pytest.raises(CategoryNotFoundError, match="No such category") as excinfo:
        pyjokes.get_joke(category='funny')
    assert "funny" in str(excinfo.value), "异常信息应明确指出无效类别"