from math_func import add, divide
import pytest

def test_add():
  
    # 测试正整数相加
    assert add(2, 3) == 5
    # 测试负数相加
    assert add(-1, -1) == -2
    # 测试正负数相加
    assert add(-1, 1) == 0
    # 测试零值
    assert add(0, 0) == 0
    assert add(5, 0) == 5
    # 测试小数
    assert add(2.5, 3.5) == 6.0

def test_divide():

    # 测试正常除法
    assert divide(6, 2) == 3
    # 测试负数除法
    assert divide(-6, 2) == -3
    assert divide(6, -2) == -3
    assert divide(-6, -2) == 3
    # 测试除以零异常
    with pytest.raises(ValueError) as excinfo:
        divide(5, 0)
    assert 'Cannot divide by zero' in str(excinfo.value)
    # 测试小数除法
    assert divide(7.5, 2.5) == 3.0

def test_add_edge_cases():
    """
    测试add函数的边界情况
    """
    # 大数相加
    large_num = 10**10
    assert add(large_num, large_num) == 2 * large_num
    # 空值测试 - Python中不会出现这种情况，但可以测试None
    try:
        add(None, 1)
        assert False, "应该抛出TypeError"
    except TypeError:
        pass

def test_divide_edge_cases():
    """
    测试divide函数的边界情况
    """
    # 零除以非零数
    assert divide(0, 5) == 0
    # 非常大的数除以非常小的数
    large_num = 10**10
    small_num = 10**-10
    assert divide(large_num, small_num) == 10**20