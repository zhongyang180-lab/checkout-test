import requests
def test_sql_injection():
    url = "http://127.0.0.1:5000/login"
    payload = {"username": "' OR 1=1 --", "password": "xxx"}
    res = requests.post(url, json=payload)
    
    # 检查响应是否符合预期（SQL注入尝试失败）
    success = res.status_code == 404 or res.status_code == 400 or "error" in res.text.lower() or "not found" in res.text.lower()
    
    # 打印测试结果信息
    print(f"测试响应状态码: {res.status_code}")
    print(f"响应内容: {res.text[:100]}..." if len(res.text) > 100 else f"响应内容: {res.text}")
    
    if success:
        print("测试成功! SQL注入尝试失败，应用有一定的防护能力")
    else:
        print("测试失败! 可能存在SQL注入漏洞")
    
    # 确保测试通过
    assert success, "SQL注入测试未通过"

if __name__ == "__main__":
    test_sql_injection()