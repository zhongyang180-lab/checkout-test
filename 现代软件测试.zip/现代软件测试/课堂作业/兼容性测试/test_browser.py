from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os

def get_absolute_path(filename):
    # 获取当前脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # 返回HTML文件的绝对路径
    return os.path.join(script_dir, filename)

def test_login_page_chrome():
    """使用Chrome浏览器测试登录页面"""
    print("开始使用Chrome浏览器测试...")
    try:
        # 设置Chrome驱动
        driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
        
        # 获取HTML文件的绝对路径并转换为file:// URL
        html_path = get_absolute_path('login.html')
        file_url = 'file:///' + html_path.replace('\\', '/')
        
        # 打开登录页面
        driver.get(file_url)
        driver.maximize_window()
        
        # 等待页面加载完成
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, "form")))
        
        # 验证页面标题包含"登录"
        assert "登录" in driver.title
        print(f"✓ 页面标题验证通过: {driver.title}")
        
        # 验证页面内容包含"用户登录"文本
        assert "用户登录" in driver.page_source
        print("✓ 页面内容验证通过，包含'用户登录'文本")
        
        # 验证登录表单元素存在
        username_field = driver.find_element(By.ID, "username")
        password_field = driver.find_element(By.ID, "password")
        submit_button = driver.find_element(By.XPATH, "//button[@type='submit']")
        
        assert username_field.is_displayed()
        assert password_field.is_displayed()
        assert submit_button.is_displayed()
        print("✓ 登录表单元素验证通过")
        
        # 测试成功登录场景
        username_field.send_keys("test")
        password_field.send_keys("test123")
        submit_button.click()
        
        # 等待JavaScript执行
        time.sleep(2)
        
        # 验证登录成功消息显示
        success_message = driver.find_element(By.ID, 'success')
        assert success_message.is_displayed()
        print("✓ 成功登录测试通过")
        
        # 测试失败登录场景
        username_field.clear()
        password_field.clear()
        username_field.send_keys("wrong_user")
        password_field.send_keys("wrong_pass")
        submit_button.click()
        
        # 等待错误消息显示
        time.sleep(2)
        error_message = driver.find_element(By.ID, 'error')
        assert error_message.is_displayed()
        print("✓ 失败登录测试通过")
        
    except Exception as e:
        print(f"✗ Chrome测试失败: {str(e)}")
        raise
    finally:
        # 关闭浏览器
        driver.quit()
        print("Chrome浏览器测试完成")

# 简单的测试运行器
def run_all_tests():
    """运行Chrome浏览器兼容性测试"""
    print("=== 开始Chrome浏览器兼容性测试 ===")
    
    tests = [
        ("Chrome", test_login_page_chrome)
    ]
    
    results = {}
    
    for browser_name, test_func in tests:
        try:
            test_func()
            results[browser_name] = "通过"
        except Exception as e:
            results[browser_name] = f"失败: {str(e)}"
    
    print("\n=== 测试结果汇总 ===")
    for browser, result in results.items():
        print(f"{browser}: {result}")

if __name__ == "__main__":
    run_all_tests()