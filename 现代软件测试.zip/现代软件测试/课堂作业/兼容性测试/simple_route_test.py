from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route('/api/pay', methods=['POST'])
def pay_endpoint():
    return jsonify({"message": "Payment endpoint reached", "status": "success"})

@app.route('/api/payment/status/<order_id>', methods=['GET'])
def status_endpoint(order_id):
    return jsonify({"order_id": order_id, "status": "success"})

@app.route('/health', methods=['GET'])
def health_endpoint():
    return jsonify({"status": "ok"})

@app.route('/', methods=['GET'])
def root_endpoint():
    return "Flask Server is running!"

if __name__ == '__main__':
    print("Starting simple route test server...")
    print("Available routes:")
    for rule in app.url_map.iter_rules():
        print(f"  {rule}")
    app.run(debug=True, host='0.0.0.0', port=5000)