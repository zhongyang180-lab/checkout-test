from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/api/pay', methods=['POST'])
def pay_endpoint():
    return jsonify({"message": "Payment endpoint reached", "status": "success"})

@app.route('/health', methods=['GET'])
def health_endpoint():
    return jsonify({"status": "ok"})

@app.route('/', methods=['GET'])
def root_endpoint():
    return "Flask Server is running on port 5002!"

if __name__ == '__main__':
    print("Starting server on port 5002...")
    for rule in app.url_map.iter_rules():
        print(f"  {rule}")
    app.run(debug=True, host='0.0.0.0', port=5002)