import requests
import time
import subprocess
import logging
import json
import sys

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('db_fault_tolerance_test')

# 测试配置
BASE_URL = "http://localhost:5000"
DB_CONTAINER_NAME = "sqlite_test_db"  # SQLite不需要Docker容器，但为了测试流程我们可以模拟
ORDER_ID = f"TEST-{int(time.time())}"
PAYMENT_AMOUNT = 100.0

# 记录测试结果
results = {
    "test_start_time": time.strftime('%Y-%m-%d %H:%M:%S'),
    "test_cases": [],
    "summary": {}
}

def check_service_health():
    """检查服务健康状态"""
    try:
        response = requests.get(f"{BASE_URL}/health", timeout=5)
        if response.status_code == 200:
            return True, response.json()
        else:
            return False, response.json()
    except Exception as e:
        return False, {"error": str(e)}

def send_payment_request(order_id, amount, test_case_name):
    """发送支付请求并记录结果"""
    test_start_time = time.time()
    test_result = {
        "name": test_case_name,
        "order_id": order_id,
        "amount": amount,
        "start_time": time.strftime('%Y-%m-%d %H:%M:%S'),
        "responses": [],
        "success": False
    }
    
    try:
        payload = {
            "order_id": order_id,
            "amount": amount
        }
        
        # 发送支付请求
        response = requests.post(f"{BASE_URL}/api/pay", json=payload, timeout=10)
        response_time = time.time() - test_start_time
        
        response_data = {
            "status_code": response.status_code,
            "response_time": response_time,
            "content": response.json() if response.headers.get('Content-Type') == 'application/json' else response.text
        }
        
        test_result["responses"].append(response_data)
        test_result["end_time"] = time.strftime('%Y-%m-%d %H:%M:%S')
        test_result["total_time"] = response_time
        
        # 检查是否成功
        if response.status_code == 200 and response_data["content"].get("success"):
            test_result["success"] = True
        
        return test_result
    
    except Exception as e:
        test_result["error"] = str(e)
        test_result["end_time"] = time.strftime('%Y-%m-%d %H:%M:%S')
        test_result["total_time"] = time.time() - test_start_time
        return test_result

def simulate_db_failure(delay_seconds=2):
    """模拟数据库故障 - 注意：对于SQLite，我们只是模拟这个过程，实际上不会停止任何服务"""
    logger.info(f"将在 {delay_seconds} 秒后模拟数据库故障...")
    time.sleep(delay_seconds)
    
    # 注意：在真实的MySQL/PostgreSQL环境中，这里应该执行 docker stop {DB_CONTAINER_NAME}
    # 但我们使用的是SQLite，所以我们只记录这个操作
    logger.info(f"[模拟操作] 执行: docker stop {DB_CONTAINER_NAME}")
    logger.info("数据库服务已停止（模拟）")
    
    # 返回模拟的命令结果
    return {"status": "simulated", "message": "数据库故障已模拟"}

def simulate_db_recovery():
    """模拟数据库恢复"""
    # 注意：在真实环境中，这里应该执行 docker start {DB_CONTAINER_NAME}
    logger.info(f"[模拟操作] 执行: docker start {DB_CONTAINER_NAME}")
    logger.info("数据库服务正在恢复中（模拟）")
    time.sleep(2)  # 模拟恢复时间
    logger.info("数据库服务已恢复（模拟）")
    
    return {"status": "simulated", "message": "数据库已恢复"}

def run_normal_payment_test():
    """运行正常支付测试"""
    logger.info("执行测试用例1: 正常支付流程")
    
    # 检查服务健康状态
    healthy, health_info = check_service_health()
    logger.info(f"服务健康状态: {'健康' if healthy else '不健康'}, 详情: {health_info}")
    
    # 发送支付请求
    test_result = send_payment_request(ORDER_ID + "-NORMAL", PAYMENT_AMOUNT, "正常支付流程")
    results["test_cases"].append(test_result)
    
    if test_result["success"]:
        logger.info("✅ 正常支付测试通过")
    else:
        logger.error("❌ 正常支付测试失败")
        logger.error(f"失败详情: {test_result}")

def run_db_failure_test():
    """运行数据库故障测试"""
    logger.info("执行测试用例2: 数据库故障时的支付处理")
    
    # 在单独的线程中模拟数据库故障
    import threading
    failure_thread = threading.Thread(target=simulate_db_failure, args=(1,))
    failure_thread.start()
    
    # 发送支付请求
    test_result = send_payment_request(ORDER_ID + "-DB-FAILURE", PAYMENT_AMOUNT, "数据库故障时的支付处理")
    results["test_cases"].append(test_result)
    
    # 等待故障模拟完成
    failure_thread.join()
    
    # 检查结果
    if test_result.get("error") or (test_result["responses"] and test_result["responses"][0]["status_code"] >= 500):
        logger.info("✅ 数据库故障测试通过 - 应用正确处理了数据库错误")
    else:
        logger.warning("⚠️ 数据库故障测试结果异常 - 应用可能没有正确检测数据库故障")

def run_recovery_test():
    """运行恢复测试"""
    logger.info("执行测试用例3: 数据库恢复后的支付处理")
    
    # 模拟数据库恢复
    simulate_db_recovery()
    
    # 等待一段时间让应用重新连接数据库
    logger.info("等待应用重新连接数据库...")
    time.sleep(3)
    
    # 检查服务健康状态
    healthy, health_info = check_service_health()
    logger.info(f"服务恢复后健康状态: {'健康' if healthy else '不健康'}, 详情: {health_info}")
    
    # 再次发送支付请求
    test_result = send_payment_request(ORDER_ID + "-RECOVERY", PAYMENT_AMOUNT, "数据库恢复后的支付处理")
    results["test_cases"].append(test_result)
    
    if test_result["success"]:
        logger.info("✅ 数据库恢复测试通过 - 应用成功恢复并处理支付")
    else:
        logger.error("❌ 数据库恢复测试失败 - 应用未能从故障中恢复")

def generate_summary():
    """生成测试摘要"""
    total_tests = len(results["test_cases"])
    passed_tests = sum(1 for tc in results["test_cases"] if tc["success"] or (tc.get("name") == "数据库故障时的支付处理" and (tc.get("error") or (tc["responses"] and tc["responses"][0]["status_code"] >= 500))))
    
    results["test_end_time"] = time.strftime('%Y-%m-%d %H:%M:%S')
    results["summary"] = {
        "total_tests": total_tests,
        "passed_tests": passed_tests,
        "success_rate": (passed_tests / total_tests * 100) if total_tests > 0 else 0,
        "conclusion": "测试通过" if passed_tests >= 2 else "测试失败"
    }

def save_results():
    """保存测试结果到文件"""
    timestamp = time.strftime('%Y%m%d_%H%M%S')
    filename = f"db_fault_tolerance_results_{timestamp}.json"
    
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    logger.info(f"测试结果已保存到: {filename}")
    return filename

def print_results_summary():
    """打印测试结果摘要"""
    print("\n" + "="*60)
    print("数据库中断容错性测试结果摘要")
    print("="*60)
    print(f"测试开始时间: {results['test_start_time']}")
    print(f"测试结束时间: {results['test_end_time']}")
    print(f"总测试用例数: {results['summary']['total_tests']}")
    print(f"通过测试数: {results['summary']['passed_tests']}")
    print(f"成功率: {results['summary']['success_rate']:.1f}%")
    print(f"结论: {results['summary']['conclusion']}")
    print("\n测试用例详情:")
    
    for i, test_case in enumerate(results['test_cases'], 1):
        print(f"\n{i}. {test_case['name']}")
        print(f"   订单ID: {test_case['order_id']}")
        print(f"   状态: {'成功' if test_case['success'] or (test_case.get('name') == '数据库故障时的支付处理' and (test_case.get('error') or (test_case['responses'] and test_case['responses'][0]['status_code'] >= 500))) else '失败'}")
        
        if test_case.get('responses'):
            for j, resp in enumerate(test_case['responses'], 1):
                print(f"   响应 {j}:")
                print(f"     状态码: {resp['status_code']}")
                print(f"     响应时间: {resp['response_time']:.3f}秒")
                if isinstance(resp['content'], dict):
                    print(f"     消息: {resp['content'].get('message', 'N/A')}")
                
        if test_case.get('error'):
            print(f"   错误: {test_case['error']}")
    
    print("\n" + "="*60)

def main():
    try:
        logger.info("开始数据库中断容错性测试")
        
        # 执行测试用例
        run_normal_payment_test()
        run_db_failure_test()
        run_recovery_test()
        
        # 生成并保存结果
        generate_summary()
        results_file = save_results()
        
        # 打印结果摘要
        print_results_summary()
        
        logger.info("测试完成")
        return 0
    
    except KeyboardInterrupt:
        logger.info("测试被用户中断")
        return 1
    except Exception as e:
        logger.error(f"测试过程中发生错误: {str(e)}")
        return 1

if __name__ == "__main__":
    sys.exit(main())