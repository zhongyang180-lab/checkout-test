def transfer(accountA, accountB, amount):
    """
    转账函数
    Args:
        accountA: 转出账户字典，包含balance键
        accountB: 转入账户字典，包含balance键  
        amount: 转账金额
    Returns:
        bool: 转账成功返回True
    Raises:
        ValueError: 金额无效或余额不足时抛出异常
    """
    if amount <= 0:
        raise ValueError("转账金额必须为正数")
    
    if accountA['balance'] < amount:
        raise ValueError("余额不足")
    
    accountA['balance'] -= amount
    accountB['balance'] += amount
    
    return True