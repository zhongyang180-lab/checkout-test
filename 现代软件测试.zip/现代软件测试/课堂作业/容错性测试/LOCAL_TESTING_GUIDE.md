# 本地容错性测试指南（无需Docker）

由于您的系统无法使用Docker（缺少虚拟化支持或Hyper-V），本指南提供了一种无需Docker即可运行容错性测试的替代方案。

## 前提条件

在开始之前，请确保您已安装以下软件：

1. **Python 3.6+** - 安装最新版本的Python
2. **MySQL服务器** - 本地安装MySQL或MariaDB

## 步骤1：安装依赖

首先，安装项目所需的Python依赖：

```bash
# 在容错性测试目录下执行
pip install -r requirements.txt
```

## 步骤2：配置MySQL数据库

1. **启动MySQL服务**：确保您的MySQL服务已启动

2. **创建数据库和用户**：
   - 连接到MySQL（使用命令行或MySQL Workbench等工具）
   - 运行以下SQL命令：
   
   ```sql
   -- 创建数据库
   CREATE DATABASE payment_db;
   
   -- 创建用户（如果需要）
   CREATE USER 'root'@'localhost' IDENTIFIED BY 'password';
   GRANT ALL PRIVILEGES ON payment_db.* TO 'root'@'localhost';
   FLUSH PRIVILEGES;
   ```

3. **创建表结构**：
   - 切换到payment_db数据库
   - 运行init.sql文件中的SQL命令：
   
   ```sql
   USE payment_db;
   
   CREATE TABLE IF NOT EXISTS orders (
       id INT AUTO_INCREMENT PRIMARY KEY,
       item VARCHAR(255) NOT NULL,
       quantity INT NOT NULL,
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
   );
   ```

## 步骤3：启动应用服务

在一个终端窗口中启动Flask应用：

```bash
# 在容错性测试目录下执行
python simple_app.py
```

您应该会看到类似以下输出：
```
* Serving Flask app 'simple_app'
* Debug mode: on
* Running on all addresses (0.0.0.0)
* Running on http://127.0.0.1:5000
```

## 步骤4：运行本地容错性测试

在另一个终端窗口中，运行我们创建的本地测试脚本：

```bash
# 在容错性测试目录下执行
python test_resilience_local.py
```

## 测试原理说明

本地测试脚本`test_resilience_local.py`的工作原理：

1. **模拟数据库故障**：
   - 不是通过Docker停止数据库容器，而是通过修改环境变量`DB_HOST`为无效值
   - 这样应用程序在尝试连接数据库时会失败

2. **验证故障响应**：
   - 测试应用在数据库不可用时是否返回适当的错误状态码（500或503）

3. **恢复数据库连接**：
   - 移除修改的环境变量，让应用恢复使用默认的数据库配置

4. **验证恢复能力**：
   - 再次尝试创建订单，验证系统是否能够从故障中恢复并正常工作

## 故障排除

如果测试失败，请检查以下几点：

1. **MySQL是否正在运行**：确保MySQL服务已经启动
2. **数据库凭据是否正确**：默认使用`root`用户和`password`密码连接到`payment_db`数据库
3. **应用是否正在运行**：确保Flask应用在端口5000上运行
4. **端口是否被占用**：如果5000端口被占用，您可能需要修改应用端口

## 注意事项

- 此本地测试方法与原始使用Docker的测试方法效果类似，都能验证应用的容错性
- 测试脚本会自动尝试确保数据库和表已创建，如果有问题会给出提示
- 如果您修改了数据库配置（用户名、密码等），请相应地修改测试脚本中的配置