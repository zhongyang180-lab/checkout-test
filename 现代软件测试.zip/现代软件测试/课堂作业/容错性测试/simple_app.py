from flask import Flask, request, jsonify
import pymysql
from pymysql import Error
import os

app = Flask(__name__)

# 数据库连接状态监控
class DatabaseStatus:
    def __init__(self):
        self.connected = False
        self.last_error = None

db_status = DatabaseStatus()

def get_db_connection():
    # 动态获取数据库配置
    current_config = {
        'host': os.getenv('DB_HOST', 'localhost'),
        'user': os.getenv('DB_USER', 'root'),
        'password': os.getenv('DB_PASSWORD', 'password'),
        'database': os.getenv('DB_NAME', 'payment_db')
    }
    
    try:
        connection = pymysql.connect(**current_config)
        db_status.connected = True
        db_status.last_error = None
        return connection
    except Error as e:
        print(f"数据库连接失败: {e}")
        db_status.connected = False
        db_status.last_error = str(e)
        return None

@app.route('/order', methods=['POST'])
def create_order():
    try:
        # 获取请求数据
        data = request.json
        if not data or 'item' not in data or 'qty' not in data:
            return jsonify({'error': '缺少必要参数'}), 400
        
        # 连接数据库
        connection = get_db_connection()
        if not connection:
            raise Error("无法连接到数据库")
        
        # 插入订单数据
        cursor = connection.cursor()
        query = "INSERT INTO orders (item, quantity) VALUES (%s, %s)"
        cursor.execute(query, (data['item'], data['qty']))
        connection.commit()
        
        order_id = cursor.lastrowid
        cursor.close()
        connection.close()
        
        return jsonify({'success': True, 'order_id': order_id}), 200
        
    except Error as e:
        print(f"数据库错误: {e}")
        return jsonify({'error': '数据库操作失败'}), 500
    except Exception as e:
        print(f"服务器错误: {e}")
        return jsonify({'error': '服务器内部错误'}), 500

@app.route('/health', methods=['GET'])
def health_check():
    # 尝试连接数据库但即使失败也返回应用程序状态
    connection = get_db_connection()
    
    app_status = "running"
    db_status_response = "connected" if db_status.connected else "disconnected"
    
    if connection:
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
            cursor.close()
            connection.close()
        except Error as e:
            db_status.connected = False
            db_status.last_error = str(e)
    
    return jsonify({
        "status": app_status,
        "database": db_status_response,
        "last_error": db_status.last_error
    }), 200

if __name__ == '__main__':
    # 直接运行脚本而不是通过flask命令
    print("Starting application...")
    try:
        app.run(host='0.0.0.0', port=5000, debug=True)
    except Exception as e:
        print(f"Error starting application: {e}")
        import traceback
        traceback.print_exc()