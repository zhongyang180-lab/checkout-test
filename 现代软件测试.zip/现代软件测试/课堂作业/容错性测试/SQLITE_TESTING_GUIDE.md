# SQLite 版本容错性测试指南

本指南提供了一个完全不依赖 MySQL 或 Docker 的容错性测试方案，使用 Python 内置的 SQLite 数据库来模拟数据库故障和恢复场景。

## 前提条件

- Python 3.6 或更高版本
- 已安装的依赖包：flask, requests

## 步骤一：安装必要依赖

打开命令行，进入项目目录，安装所需的 Python 包：

```bash
# 使用项目已有的 requirements.txt
pip install -r requirements.txt

# 或者单独安装需要的包
pip install flask requests
```

## 步骤二：启动应用程序

运行 SQLite 版本的应用程序：

```bash
# 直接运行 SQLite 版本的应用
python simple_app_sqlite.py
```

这将启动一个 Flask 应用，监听在 http://localhost:5000，并自动创建一个 SQLite 数据库文件 `test_db.sqlite` 在当前目录下。

## 步骤三：运行容错性测试

在另一个命令行窗口中，运行测试脚本：

```bash
python test_resilience_sqlite.py
```

## 测试内容说明

测试脚本将执行以下测试场景：

1. **正常操作测试**：验证应用在正常状态下的功能
2. **数据库故障测试**：通过 API 模拟数据库故障，验证应用的错误处理能力
3. **故障恢复测试**：恢复数据库连接，验证应用能否正常恢复
4. **多次故障恢复测试**：模拟多次故障和恢复，验证系统的稳定性

## 工作原理

### 应用程序特点

- 使用 Python 内置的 SQLite 数据库，无需额外安装数据库软件
- 通过 `/inject_failure` API 接口可以远程控制数据库连接状态
- 即使数据库「故障」，应用程序仍能保持运行并提供健康检查
- 详细的错误日志输出，方便调试

### 测试脚本特点

- 自动化执行完整的容错性测试流程
- 清晰的测试结果输出和评分
- 详细的测试过程日志
- 支持手动中断和再次运行

## 手动测试指南

如果需要手动测试特定场景，可以使用以下 curl 命令或任何 HTTP 客户端（如 Postman）：

### 1. 检查健康状态

```bash
curl http://localhost:5000/health
```

### 2. 创建订单

```bash
curl -X POST -H "Content-Type: application/json" -d '{"order_id":"manual-test-123","amount":99.99}' http://localhost:5000/order
```

### 3. 注入数据库故障

```bash
curl -X POST -H "Content-Type: application/json" -d '{"fail":true}' http://localhost:5000/inject_failure
```

### 4. 恢复数据库连接

```bash
curl -X POST -H "Content-Type: application/json" -d '{"fail":false}' http://localhost:5000/inject_failure
```

## 故障排除

### 端口被占用
如果遇到端口 5000 被占用的情况，可以修改 `simple_app_sqlite.py` 文件中的端口号：

```python
# 在文件末尾修改端口号
app.run(host='0.0.0.0', port=5001, debug=True)
```

同时也需要修改 `test_resilience_sqlite.py` 文件中的 APP_URL：

```python
APP_URL = "http://localhost:5001"
```

### 数据库文件权限问题
如果遇到 SQLite 数据库文件权限问题，可以尝试删除 `test_db.sqlite` 文件，应用程序会自动重新创建。

### 依赖包版本冲突
如果遇到依赖包版本冲突，可以尝试使用虚拟环境：

```bash
# 创建虚拟环境
python -m venv venv

# 激活虚拟环境 (Windows)
venv\Scripts\activate

# 激活虚拟环境 (Linux/Mac)
source venv/bin/activate

# 安装依赖
pip install -r requirements.txt
```

## 测试完成后

测试完成后，可以按 `Ctrl+C` 停止运行中的应用程序。

SQLite 数据库文件 `test_db.sqlite` 可以保留以便后续查看数据，也可以删除以释放空间。

## 测试报告

测试脚本执行完成后，会在控制台输出详细的测试报告，包括：
- 各项测试的通过/失败状态
- 总体测试通过率
- 容错性评分

您可以将这些结果复制到您的课程作业报告中作为测试证据。