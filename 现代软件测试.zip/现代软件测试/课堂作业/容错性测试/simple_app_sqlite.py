from flask import Flask, request, jsonify
import sqlite3
import os
import time

# 初始化Flask应用
app = Flask(__name__)

# 数据库连接状态监控
class DatabaseStatus:
    def __init__(self):
        self.connected = False
        self.last_error = None
        self.db_path = os.path.join(os.getcwd(), 'test_db.sqlite')
        self.is_simulating_failure = False

db_status = DatabaseStatus()

# 初始化SQLite数据库
def init_database():
    try:
        # 检查表是否存在，如果不存在则创建
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id TEXT NOT NULL,
            amount REAL NOT NULL,
            status TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"初始化数据库失败: {e}")
        return False

# 获取数据库连接
def get_db_connection():
    # 检查是否正在模拟故障
    if db_status.is_simulating_failure:
        db_status.connected = False
        db_status.last_error = "数据库故障模拟: 无法连接到数据库"
        return None
    
    try:
        # SQLite连接
        connection = sqlite3.connect(db_status.db_path)
        connection.row_factory = sqlite3.Row  # 允许通过列名访问
        db_status.connected = True
        db_status.last_error = None
        return connection
    except Exception as e:
        print(f"数据库连接失败: {e}")
        db_status.connected = False
        db_status.last_error = str(e)
        return None

# 订单创建接口
@app.route('/order', methods=['POST'])
def create_order():
    connection = get_db_connection()
    if not connection:
        return jsonify({"error": "数据库连接失败", "details": db_status.last_error}), 503
    
    try:
        data = request.get_json()
        if not data or 'order_id' not in data or 'amount' not in data:
            return jsonify({"error": "请求参数不完整"}), 400
        
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO orders (order_id, amount, status) VALUES (?, ?, ?)",
            (data['order_id'], data['amount'], 'pending')
        )
        connection.commit()
        order_id = cursor.lastrowid
        cursor.close()
        connection.close()
        
        return jsonify({"id": order_id, "order_id": data['order_id'], "status": "created"}), 201
    except Exception as e:
        if connection:
            connection.close()
        return jsonify({"error": "创建订单失败", "details": str(e)}), 500

# 健康检查接口
@app.route('/health', methods=['GET'])
def health_check():
    # 尝试连接数据库但即使失败也返回应用程序状态
    connection = get_db_connection()
    
    app_status = "running"
    db_status_response = "connected" if db_status.connected else "disconnected"
    
    if connection:
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
            cursor.close()
            connection.close()
        except Exception as e:
            db_status.connected = False
            db_status.last_error = str(e)
    
    return jsonify({
        "status": app_status,
        "database": db_status_response,
        "last_error": db_status.last_error,
        "using_sqlite": True
    }), 200

# 故障注入接口（用于测试）
@app.route('/inject_failure', methods=['POST'])
def inject_failure():
    data = request.get_json()
    if data and 'fail' in data:
        db_status.is_simulating_failure = data['fail']
        if data['fail']:
            db_status.connected = False
            db_status.last_error = "模拟数据库故障"
        return jsonify({"status": "success", "fail": db_status.is_simulating_failure}), 200
    return jsonify({"error": "无效的请求参数"}), 400

# 初始化数据库
db_path = os.path.join(os.getcwd(), 'test_db.sqlite')
init_database()

if __name__ == '__main__':
    print("Starting application with SQLite...")
    print(f"Database path: {db_status.db_path}")
    try:
        app.run(host='0.0.0.0', port=5000, debug=True)
    except Exception as e:
        print(f"Error starting application: {e}")
        import traceback
        traceback.print_exc()
