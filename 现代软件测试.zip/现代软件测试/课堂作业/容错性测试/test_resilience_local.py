import requests
import time
import mysql.connector
import os
from mysql.connector import Error

# 数据库配置
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'password',
    'database': 'payment_db'
}

def disable_db_connection():
    """通过修改应用使用的数据库配置来模拟数据库故障"""
    # 修改环境变量或配置来模拟数据库连接失败
    os.environ['DB_HOST'] = 'nonexistent_host'  # 无效的主机名
    print("模拟数据库故障：修改数据库连接配置")

def restore_db_connection():
    """恢复正常的数据库连接配置"""
    # 移除修改的环境变量，让应用使用默认配置
    if 'DB_HOST' in os.environ:
        del os.environ['DB_HOST']
    print("恢复数据库连接：重置数据库配置")

def ensure_database_ready():
    """确保数据库已创建并可访问"""
    try:
        # 首先连接MySQL服务器
        conn = mysql.connector.connect(
            host=db_config['host'],
            user=db_config['user'],
            password=db_config['password']
        )
        cursor = conn.cursor()
        
        # 检查并创建数据库
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_config['database']}")
        cursor.execute(f"USE {db_config['database']}")
        
        # 创建orders表
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            item VARCHAR(255) NOT NULL,
            quantity INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """
        cursor.execute(create_table_sql)
        
        conn.commit()
        cursor.close()
        conn.close()
        print("数据库已准备就绪")
        return True
    except Error as e:
        print(f"数据库准备失败: {e}")
        return False

def test_db_failure_recovery():
    # 确保数据库已准备好
    if not ensure_database_ready():
        print("警告：无法准备数据库环境，请确保MySQL已安装并运行")
    
    # 模拟数据库故障
    disable_db_connection()
    
    # 尝试创建订单，应该失败
    print("尝试在数据库故障状态下创建订单...")
    try:
        res = requests.post("http://127.0.0.1:5000/order", json={"item": "book", "qty": 1}, timeout=5)
        print(f"请求返回状态码: {res.status_code}")
        assert res.status_code in (500, 503), f"期望状态码500或503，实际得到{res.status_code}"
        print("✓ 系统正确识别到数据库故障")
    except requests.exceptions.ConnectionError:
        print("✓ 系统无法连接，符合预期")
    except requests.exceptions.Timeout:
        print("✓ 请求超时，符合预期")
    
    # 等待一会儿
    time.sleep(2)
    
    # 恢复数据库连接
    print("恢复数据库连接...")
    restore_db_connection()
    time.sleep(3)  # 给系统一些恢复时间
    
    # 尝试再次创建订单，应该成功
    print("尝试在数据库恢复后创建订单...")
    try:
        res2 = requests.post("http://127.0.0.1:5000/order", json={"item": "book", "qty": 1}, timeout=5)
        print(f"请求返回状态码: {res2.status_code}")
        if res2.status_code == 200:
            print("✓ 系统成功从数据库故障中恢复")
            print(f"订单创建成功，订单ID: {res2.json().get('order_id')}")
        else:
            print(f"✗ 系统恢复失败，状态码: {res2.status_code}")
            assert False, f"期望状态码200，实际得到{res2.status_code}"
    except Exception as e:
        print(f"✗ 系统恢复失败: {e}")
        assert False, f"系统未能从数据库故障中恢复: {e}"

if __name__ == "__main__":
    print("开始容错性测试...")
    test_db_failure_recovery()
    print("\n🎉 测试通过！系统能够在模拟的数据库中断后正确报错并在恢复后正常工作。")
    print("\n注意：此测试使用环境变量模拟数据库故障，与使用Docker的原始测试方法效果类似。")