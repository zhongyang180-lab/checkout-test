import requests
import time
import json

# 测试配置
APP_URL = "http://localhost:5000"
HEALTH_ENDPOINT = f"{APP_URL}/health"
ORDER_ENDPOINT = f"{APP_URL}/order"
FAILURE_ENDPOINT = f"{APP_URL}/inject_failure"

# 测试用例
def test_normal_operation():
    """测试正常运行状态下的API功能"""
    print("\n=== 测试正常运行状态 ===")
    
    # 1. 检查健康状态
    print("1. 检查健康状态...")
    response = requests.get(HEALTH_ENDPOINT)
    print(f"健康检查响应: {response.status_code}, 内容: {response.text}")
    
    # 2. 创建测试订单
    print("\n2. 创建测试订单...")
    order_data = {"order_id": f"test-{int(time.time())}", "amount": 100.00}
    response = requests.post(ORDER_ENDPOINT, json=order_data)
    print(f"创建订单响应: {response.status_code}, 内容: {response.text}")
    
    return response.status_code == 201

def test_database_failure():
    """测试数据库故障状态"""
    print("\n=== 测试数据库故障状态 ===")
    
    # 1. 注入数据库故障
    print("1. 注入数据库故障...")
    response = requests.post(FAILURE_ENDPOINT, json={"fail": True})
    print(f"故障注入响应: {response.status_code}, 内容: {response.text}")
    
    # 2. 检查健康状态
    print("\n2. 检查故障状态下的健康检查...")
    response = requests.get(HEALTH_ENDPOINT)
    print(f"故障状态健康检查: {response.status_code}, 内容: {response.text}")
    
    # 3. 尝试创建订单（应该失败）
    print("\n3. 尝试在故障状态下创建订单...")
    order_data = {"order_id": f"test-fail-{int(time.time())}", "amount": 100.00}
    response = requests.post(ORDER_ENDPOINT, json=order_data)
    print(f"故障状态创建订单: {response.status_code}, 内容: {response.text}")
    
    # 检查是否返回了适当的错误响应
    is_expected_error = response.status_code == 503
    print(f"故障状态预期错误响应: {'✓' if is_expected_error else '✗'}")
    
    return is_expected_error

def test_recovery():
    """测试数据库恢复后的操作"""
    print("\n=== 测试数据库恢复状态 ===")
    
    # 1. 恢复数据库连接
    print("1. 恢复数据库连接...")
    response = requests.post(FAILURE_ENDPOINT, json={"fail": False})
    print(f"恢复连接响应: {response.status_code}, 内容: {response.text}")
    
    # 等待一会儿让系统恢复
    print("\n等待系统恢复...")
    time.sleep(2)
    
    # 2. 检查健康状态
    print("\n2. 检查恢复后的健康状态...")
    response = requests.get(HEALTH_ENDPOINT)
    print(f"恢复后健康检查: {response.status_code}, 内容: {response.text}")
    
    # 3. 尝试创建订单（应该成功）
    print("\n3. 尝试在恢复后创建订单...")
    order_data = {"order_id": f"test-recovery-{int(time.time())}", "amount": 150.00}
    response = requests.post(ORDER_ENDPOINT, json=order_data)
    print(f"恢复后创建订单: {response.status_code}, 内容: {response.text}")
    
    # 检查是否成功创建订单
    is_recovered = response.status_code == 201
    print(f"系统恢复成功: {'✓' if is_recovered else '✗'}")
    
    return is_recovered

def test_repeated_failures():
    """测试多次故障恢复场景"""
    print("\n=== 测试多次故障恢复场景 ===")
    
    failures_count = 3
    success_count = 0
    
    for i in range(failures_count):
        print(f"\n--- 故障循环 {i+1}/{failures_count} ---")
        
        # 注入故障
        print(f"1. 第{i+1}次注入故障...")
        requests.post(FAILURE_ENDPOINT, json={"fail": True})
        time.sleep(1)
        
        # 恢复故障
        print(f"2. 第{i+1}次恢复故障...")
        requests.post(FAILURE_ENDPOINT, json={"fail": False})
        time.sleep(2)
        
        # 验证恢复
        print(f"3. 第{i+1}次验证恢复状态...")
        order_data = {"order_id": f"test-cycle-{i}-{int(time.time())}", "amount": 200.00}
        response = requests.post(ORDER_ENDPOINT, json=order_data)
        
        if response.status_code == 201:
            success_count += 1
            print(f"  恢复成功 ✓")
        else:
            print(f"  恢复失败 ✗: {response.status_code}, {response.text}")
    
    print(f"\n多次故障测试结果: {success_count}/{failures_count} 次成功恢复")
    return success_count == failures_count

def main():
    """主测试函数"""
    print("==============================================")
    print("      SQLite版本容错性测试")
    print("==============================================")
    print(f"测试目标: {APP_URL}")
    print("\n注意: 请确保simple_app_sqlite.py已经启动运行!")
    print("==============================================\n")
    
    # 检查服务是否运行
    try:
        response = requests.get(HEALTH_ENDPOINT, timeout=5)
        print(f"服务检查: 正常 ({response.status_code})")
    except requests.exceptions.RequestException as e:
        print(f"错误: 无法连接到服务 - {e}")
        print("请确保simple_app_sqlite.py已经启动运行!")
        return
    
    # 运行测试套件
    tests = [
        ("正常操作", test_normal_operation),
        ("数据库故障", test_database_failure),
        ("故障恢复", test_recovery),
        ("多次故障恢复", test_repeated_failures)
    ]
    
    results = []
    for name, test_func in tests:
        print(f"\n{'='*50}")
        print(f"运行测试: {name}")
        print(f"{'='*50}")
        
        try:
            success = test_func()
            results.append((name, success))
            print(f"\n测试结果: {'通过 ✓' if success else '失败 ✗'}")
        except Exception as e:
            results.append((name, False))
            print(f"\n测试错误: {e}")
            print(f"测试结果: 失败 ✗")
    
    # 总结
    print("\n==============================================")
    print("                  测试总结")
    print("==============================================")
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    for name, success in results:
        print(f"{name}: {'通过 ✓' if success else '失败 ✗'}")
    
    print(f"\n总体结果: {passed}/{total} 测试通过")
    print(f"容错性评分: {int(passed/total*100)}%")
    print("==============================================")
    
    if passed == total:
        print("\n🎉 所有测试通过！应用程序具有良好的容错能力。")
    else:
        print("\n⚠️ 部分测试失败，需要改进应用程序的容错机制。")

if __name__ == "__main__":
    main()
