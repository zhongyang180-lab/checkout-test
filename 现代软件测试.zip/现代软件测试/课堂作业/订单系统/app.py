from flask import Flask, request, Response
from inventory import Inventory
from payment import PaymentProcessor
from order import OrderManager
import json

app = Flask(__name__)

# 初始化模块
inventory = Inventory()
payment_processor = PaymentProcessor()
order_manager = OrderManager(inventory, payment_processor)

def create_success_response(data=None, message="操作成功"):
    """创建成功响应"""
    response = {
        "success": True,
        "message": message,
        "code": 200
    }
    if data:
        response["data"] = data
    
    # 使用json.dumps确保中文直接显示
    json_str = json.dumps(response, ensure_ascii=False)
    return Response(json_str, mimetype='application/json'), 200

def create_error_response(message, code=400):
    """创建错误响应"""
    response = {
        "success": False,
        "message": message,
        "code": code
    }
    
    # 使用json.dumps确保中文直接显示
    json_str = json.dumps(response, ensure_ascii=False)
    return Response(json_str, mimetype='application/json'), code

@app.route("/order", methods=["POST"])
def create_order():
    """创建订单接口"""
    try:
        data = request.json
        if not data:
            return create_error_response("请求数据不能为空")
            
        item = data.get("item")
        qty = data.get("qty", 1)
        amount = data.get("amount", 0)
        
        # 验证必填字段
        if not item:
            return create_error_response("商品名称不能为空")
        if not qty:
            return create_error_response("商品数量不能为空")
        if not amount:
            return create_error_response("支付金额不能为空")
        
        # 创建订单
        result = order_manager.create_order(item, qty, amount)
        return create_success_response(result, "订单创建成功")
        
    except Exception as e:
        return create_error_response(str(e))

@app.route("/inventory/<item>", methods=["GET"])
def get_inventory(item):
    """查询库存接口"""
    try:
        stock = inventory.get_stock(item)
        return create_success_response({
            "item": item,
            "stock": stock
        }, f"查询商品 '{item}' 库存成功")
    except Exception as e:
        return create_error_response(str(e))

@app.route("/payment/status/<order_id>", methods=["GET"])
def get_payment_status(order_id):
    """查询支付状态接口"""
    try:
        status = payment_processor.get_payment_status(order_id)
        return create_success_response({
            "order_id": order_id,
            "status": status
        }, f"查询订单 '{order_id}' 支付状态成功")
    except Exception as e:
        return create_error_response(str(e))

if __name__ == "__main__":
    app.run(debug=True, port=5000)