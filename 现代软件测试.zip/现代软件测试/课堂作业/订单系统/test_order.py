import pytest
from order import OrderManager
from inventory import Inventory
from payment import PaymentProcessor

class TestOrderManager:
    """订单管理模块单元测试"""
    
    def setup_method(self):
        self.inventory = Inventory()
        self.payment = PaymentProcessor()
        self.order_manager = OrderManager(self.inventory, self.payment)
    
    def test_create_order_success(self):
        """测试成功创建订单"""
        result = self.order_manager.create_order("book", 2, 200)
        assert result["success"] == True
        assert result["payment_status"] == "success"
        assert result["remaining_stock"] == 8
    
    def test_create_order_invalid_item(self):
        """测试创建订单（无效商品）"""
        with pytest.raises(ValueError, match="商品 'invalid_item' 不存在"):
            self.order_manager.create_order("invalid_item", 1, 100)
    
    def test_create_order_invalid_quantity(self):
        """测试创建订单（无效数量）"""
        with pytest.raises(ValueError, match="商品数量必须大于0"):
            self.order_manager.create_order("book", 0, 100)
    
    def test_create_order_insufficient_stock(self):
        """测试创建订单（库存不足）"""
        with pytest.raises(ValueError, match="库存不足"):
            self.order_manager.create_order("book", 20, 100)
    
    def test_create_order_payment_failed(self):
        """测试创建订单（支付失败）"""
        result = self.order_manager.create_order("book", 1, 2000)
        assert result["success"] == True  # 订单创建成功，但支付失败
        assert result["payment_status"] == "failed"
    
    def test_create_order_empty_item(self):
        """测试创建订单时商品名称为空"""
        inventory = Inventory()
        payment_processor = PaymentProcessor()
        order_manager = OrderManager(inventory, payment_processor)
        
        with pytest.raises(ValueError, match="商品名称不能为空"):
            order_manager.create_order("", 2, 100)
    
    def test_create_order_negative_amount(self):
        """测试创建订单时支付金额为负数"""
        inventory = Inventory()
        payment_processor = PaymentProcessor()
        order_manager = OrderManager(inventory, payment_processor)
        
        with pytest.raises(ValueError, match="支付金额不能为负数"):
            order_manager.create_order("apple", 2, -100)
    
    def test_create_order_exception_rollback(self):
        """测试创建订单异常时的库存回滚机制"""
        inventory = Inventory()
        payment_processor = PaymentProcessor()
        order_manager = OrderManager(inventory, payment_processor)
        
        # 设置初始库存
        inventory.add_stock("test_item", 10)
        
        # 模拟支付失败
        def mock_process_payment(order_id, amount):
            raise Exception("模拟支付失败")
        
        payment_processor.process_payment = mock_process_payment
        
        with pytest.raises(Exception, match="模拟支付失败"):
            order_manager.create_order("test_item", 2, 100)
        
        # 验证库存已回滚
        assert inventory.get_stock("test_item") == 10