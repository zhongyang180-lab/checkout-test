import pytest
from payment import PaymentProcessor

class TestPaymentProcessor:
    """支付模块单元测试"""
    
    def setup_method(self):
        self.processor = PaymentProcessor()
    
    def test_process_payment_success(self):
        """测试支付成功"""
        result = self.processor.process_payment("order_001", 100)
        assert result["status"] == "success"
        assert "pay_" in result["payment_id"]
    
    def test_process_payment_failed_due_to_amount(self):
        """测试支付失败（金额超限）"""
        result = self.processor.process_payment("order_002", 1500)
        assert result["status"] == "failed"
        assert "金额超过1000元限制" in result["message"]  # 修改为匹配实际消息
    
    def test_process_payment_invalid_amount(self):
        """测试无效支付金额"""
        with pytest.raises(ValueError, match="支付金额必须大于0"):
            self.processor.process_payment("order_003", 0)
    
    def test_get_payment_status_existing(self):
        """测试获取存在的支付状态"""
        self.processor.process_payment("order_004", 50)
        status = self.processor.get_payment_status("order_004")
        assert status == "success"
    
    def test_get_payment_status_nonexistent(self):
        """测试获取不存在的支付状态"""
        with pytest.raises(ValueError, match="订单 'nonexistent' 不存在"):
            self.processor.get_payment_status("nonexistent")