from locust import HttpUser, task, between

class WebsiteUser(HttpUser):
    wait_time = between(1, 3)
    host = "http://127.0.0.1:5000"
    
    @task
    def order_book(self):
        self.client.post("/order",
                        json={"item": "book",
                              "qty": 1,
                              "amount": 100})
