class Inventory:
    """库存管理模块"""
    
    def __init__(self):
        # 初始化库存
        self.stock = {
            "book": 10,
            "pen": 20,
            "notebook": 15
        }
    
    def get_stock(self, item):
        """获取商品库存"""
        if item not in self.stock:
            raise ValueError(f"商品 '{item}' 不存在")
        return self.stock[item]
    
    def reduce_stock(self, item, quantity):
        """减少库存"""
        if item not in self.stock:
            raise ValueError(f"商品 '{item}' 不存在")
        
        if self.stock[item] < quantity:
            raise ValueError(f"商品 '{item}' 库存不足，当前库存: {self.stock[item]}")
        
        self.stock[item] -= quantity
        return self.stock[item]
    
    def add_stock(self, item, quantity):
        """增加库存"""
        if item not in self.stock:
            self.stock[item] = 0
        self.stock[item] += quantity
        return self.stock[item]