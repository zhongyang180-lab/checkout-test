class PaymentProcessor:
    """支付处理模块"""
    
    def __init__(self):
        self.payments = {}  # 存储支付记录
        self.payment_id_counter = 1
    
    def process_payment(self, order_id, amount):
        """处理支付"""
        if amount <= 0:
            raise ValueError("支付金额必须大于0")
        
        # 模拟支付处理
        payment_id = f"pay_{self.payment_id_counter}"
        self.payment_id_counter += 1
        
        # 模拟支付成功（金额大于1000元时失败，模拟支付限制）
        if amount > 1000:
            status = "failed"
            message = "支付失败：金额超过1000元限制"
        else:
            status = "success"
            message = "支付成功"
        
        self.payments[order_id] = {
            "payment_id": payment_id,
            "amount": amount,
            "status": status,
            "message": message
        }
        
        return {
            "payment_id": payment_id,
            "status": status,
            "message": message
        }
    
    def get_payment_status(self, order_id):
        """获取支付状态"""
        if order_id not in self.payments:
            raise ValueError(f"订单 '{order_id}' 不存在")
        return self.payments[order_id]["status"]