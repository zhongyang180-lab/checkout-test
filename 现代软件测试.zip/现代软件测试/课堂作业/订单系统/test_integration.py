import pytest
import requests
import time
import threading
from app import app

class TestOrderSystemIntegration:
    """订单系统集成测试"""
    
    @classmethod
    def setup_class(cls):
        """启动测试服务器"""
        cls.server_thread = threading.Thread(
            target=lambda: app.run(port=5001, debug=False, use_reloader=False)
        )
        cls.server_thread.daemon = True
        cls.server_thread.start()
        time.sleep(2)  # 等待服务器启动
    
    def test_order_creation_success(self):
        """测试成功创建订单（集成测试）"""
        url = "http://127.0.0.1:5001/order"
        data = {
            "item": "book",
            "qty": 2,
            "amount": 200
        }
        
        response = requests.post(url, json=data)
        assert response.status_code == 200
        result = response.json()
        assert result["success"] == True
        assert result["data"]["payment_status"] == "success"  # 修复：从data中获取
    
    def test_order_creation_insufficient_stock(self):
        """测试创建订单（库存不足）"""
        url = "http://127.0.0.1:5001/order"
        data = {
            "item": "book",
            "qty": 50,  # 超过库存
            "amount": 100
        }
        
        response = requests.post(url, json=data)
        assert response.status_code == 400
        result = response.json()
        assert result["success"] == False
        assert "库存不足" in result["message"]  # 修复：从message中获取错误信息
    
    def test_order_creation_invalid_item(self):
        """测试创建订单（无效商品）"""
        url = "http://127.0.0.1:5001/order"
        data = {
            "item": "nonexistent_item",
            "qty": 1,
            "amount": 100
        }
        
        response = requests.post(url, json=data)
        assert response.status_code == 400
        result = response.json()
        assert result["success"] == False
        assert "不存在" in result["message"]  # 修复：从message中获取错误信息
    
    def test_get_inventory(self):
        """测试获取库存信息"""
        url = "http://127.0.0.1:5001/inventory/book"
        response = requests.get(url)
        assert response.status_code == 200
        result = response.json()
        assert result["success"] == True
        assert "stock" in result["data"]  # 修复：从data中获取库存信息
        assert result["data"]["item"] == "book"
    
    def test_payment_status(self):
        """测试获取支付状态"""
        # 先创建订单
        order_url = "http://127.0.0.1:5001/order"
        order_data = {"item": "pen", "qty": 1, "amount": 50}
        order_response = requests.post(order_url, json=order_data)
        order_result = order_response.json()
        order_id = order_result["data"]["order_id"]  # 修复：从data中获取order_id
        
        # 查询支付状态
        payment_url = f"http://127.0.0.1:5001/payment/status/{order_id}"
        payment_response = requests.get(payment_url)
        assert payment_response.status_code == 200
        result = payment_response.json()
        assert result["success"] == True
        assert result["data"]["status"] in ["success", "failed"]  # 修复：从data中获取状态