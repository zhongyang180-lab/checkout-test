import pytest
from inventory import Inventory

class TestInventory:
    """库存模块单元测试"""
    
    def setup_method(self):
        self.inventory = Inventory()
    
    def test_get_stock_existing_item(self):
        """测试获取存在的商品库存"""
        stock = self.inventory.get_stock("book")
        assert stock == 10
    
    def test_get_stock_nonexistent_item(self):
        """测试获取不存在的商品库存"""
        with pytest.raises(ValueError, match="商品 'pencil' 不存在"):
            self.inventory.get_stock("pencil")
    
    def test_reduce_stock_success(self):
        """测试成功减少库存"""
        remaining = self.inventory.reduce_stock("book", 3)
        assert remaining == 7
        assert self.inventory.get_stock("book") == 7
    
    def test_reduce_stock_insufficient(self):
        """测试库存不足"""
        with pytest.raises(ValueError, match="库存不足"):
            self.inventory.reduce_stock("book", 15)
    
    def test_add_stock_existing_item(self):
        """测试增加已有商品库存"""
        stock = self.inventory.add_stock("book", 5)
        assert stock == 15
        assert self.inventory.get_stock("book") == 15
    
    def test_add_stock_new_item(self):
        """测试增加新商品库存"""
        stock = self.inventory.add_stock("pencil", 10)
        assert stock == 10
        assert self.inventory.get_stock("pencil") == 10