import uuid

class OrderManager:
    """订单管理模块"""
    
    def __init__(self, inventory, payment_processor):
        self.inventory = inventory
        self.payment_processor = payment_processor
        self.orders = {}  # 存储订单记录
    
    def create_order(self, item, quantity, amount):
        """创建订单"""
        # 验证参数
        if not item:
            raise ValueError("商品名称不能为空")
        if quantity <= 0:
            raise ValueError("商品数量必须大于0")
        if amount < 0:
            raise ValueError("支付金额不能为负数")
        
        # 生成订单ID
        order_id = str(uuid.uuid4())[:8]
        
        try:
            # 检查库存
            remaining_stock = self.inventory.reduce_stock(item, quantity)
            
            # 处理支付
            payment_result = self.payment_processor.process_payment(order_id, amount)
            
            # 保存订单
            self.orders[order_id] = {
                "item": item,
                "quantity": quantity,
                "amount": amount,
                "inventory_result": remaining_stock,
                "payment_result": payment_result
            }
            
            return {
                "order_id": order_id,
                "success": True,
                "message": "订单创建成功",
                "remaining_stock": remaining_stock,
                "payment_status": payment_result["status"]
            }
            
        except Exception as e:
            # 如果出现异常，回滚库存（无论订单是否已保存）
            self.inventory.add_stock(item, quantity)  # 修复：直接回滚库存
            raise e